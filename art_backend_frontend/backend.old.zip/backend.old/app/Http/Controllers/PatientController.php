<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Patient;

class PatientController extends Controller
{
    public function store(Request $request)
{
    $validated = $request->validate([
        'name' => 'required|string',
        'age' => 'nullable|integer',
        'gender' => 'required|string',
        'medicalHistory' => 'nullable|string',
        'medications' => 'nullable|string',
        'remarks' => 'nullable|string',
    ]);

    $patient = Patient::create([
        'name' => $validated['name'],
        'age' => $validated['age'],
        'gender' => $validated['gender'],
        'medical_history' => $validated['medicalHistory'],
        'medications' => $validated['medications'],
        'remarks' => $validated['remarks'],
    ]);

    return response()->json(['message' => 'Patient saved', 'data' => $patient], 201);
}

    public function index()
    {
        return response()->json(Patient::all());
    }

    public function show($id)
{
    $patient = Patient::find($id);

    if (!$patient) {
        return response()->json(['error' => 'Not found'], 404);
    }

    return response()->json($patient);
}

}

