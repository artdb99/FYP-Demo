import { Link } from 'react-router-dom';

function Layout({ children }) {
  return (
    <div className="dashboard">
      {/* Header */}
      <header className="header">
        <button className="menu-button">☰</button>
        <h1></h1>
        <div className="profile-icon">👤</div>
      </header>

      {/* Sidebar */}
      <aside className="sidebar">
        <h2>Dashboard</h2>
        <nav>
          <h3>Patients</h3>
          <ul>
            <li><Link to="/patients">List of Patients</Link></li>
            <li><Link to="/patients/create">Create Patient</Link></li>
          </ul>

        <h3>Functions</h3>
        <ul className="sidebar-links">
        <li><Link to="/predict">Predict HBA1C</Link></li>
        </ul>

        <ul className="sidebar-links">
          <li><Link to="/therapy-effectiveness">Therapy Effectiveness</Link></li>
          </ul>

        <ul className="sidebar-links">
          <li><Link to="/treatment-recommendation">Treatment Recommendation</Link></li>
        </ul>
        
        </nav>
      </aside>

      {/* Main Content */}
      <main className="main-content">
        {children}
      </main>
    </div>
  );
}

export default Layout;