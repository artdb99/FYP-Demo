import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './Layout';
import Dashboard from './pages/Dashboard';
import PatientsList from './pages/PatientsList';
import PatientProfile from './pages/PatientProfile'; // Importing PatientProfile
import RiskPredictionForm from './pages/RiskPredictionForm';
import CreatePatient from './pages/CreatePatient'; // Importing CreatePatient
import TherapyDashboard from './pages/TherapyDashboard'; // Importing TherapyDashboard
import TherapyEffectivenessForm from './pages/TherapyEffectivenessForm';
import TreatmentRecommendationForm from './pages/TreatmentRecommendationForm';
import './App.css';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/patients" element={<PatientsList />} />

          {/* Parent route with nested routes */}
          <Route path="/patient/:id/*" element={<PatientProfile />} />

          <Route path="/predict" element={<RiskPredictionForm />} />
          <Route path="/therapy-effectiveness" element={<TherapyDashboard />} />
          <Route path="/therapy-effectiveness/:id" element={<TherapyEffectivenessForm />} />

          {/* Route for TreatmentRecommendationForm */}
          <Route path="/treatment-recommendation" element={<TreatmentRecommendationForm />} />

          {/* Route for CreatePatient */}
          <Route path="/patients/create" element={<CreatePatient />} /> {/* Route for CreatePatient */}
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;
