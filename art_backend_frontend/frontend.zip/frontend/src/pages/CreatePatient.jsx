import React, { useState } from 'react';

const CreatePatient = () => {
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: '',
    medicalHistory: '',
    medications: '',
    remarks: '',
    insulinType: '',
    fvg: '',
    hba1c1: '',
    hba1c2: '',
    symptomBefore: '',
    symptomAfter: '',
    hypoBefore: '',
    hypoAfter: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    fetch('http://localhost:8000/api/patients', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    })
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP error! Status: ${res.status}`);
        return res.json();
      })
      .then((data) => {
        console.log('Success:', data);
        alert('Patient created!');
      })
      .catch((err) => {
        console.error('Submission error:', err);
        alert('Something went wrong. Check console.');
      });
  };

  return (
    <div className="max-w-screen-lg mx-auto px-6 py-12">
      <h2 className="text-3xl font-bold text-blue-700 mb-8 text-center">Create New Patient</h2>
      <form onSubmit={handleSubmit} className="bg-white shadow-lg rounded-lg p-8 space-y-6">
        {/* Basic Info */}
        <div>
          <h3 className="text-xl font-semibold text-gray-700 mb-3 border-b pb-1">🧍 Basic Information</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <input className="input" name="name" placeholder="Name" value={formData.name} onChange={handleChange} required />
            <input className="input" name="age" type="number" placeholder="Age" value={formData.age} onChange={handleChange} required />

            <select className="input" name="gender" value={formData.gender} onChange={handleChange} required>
              <option value="">-- Select Gender --</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>

            <select className="input" name="insulinType" value={formData.insulinType} onChange={handleChange} required>
              <option value="">-- Insulin Regimen Type --</option>
              <option value="Basal">Basal</option>
              <option value="Bolus">Bolus</option>
              <option value="Premixed">Premixed</option>
              <option value="Basal-Bolus">Basal-Bolus</option>
              <option value="None">None</option>
            </select>
          </div>
        </div>

        {/* Medical Info */}
        <div>
          <h3 className="text-xl font-semibold text-gray-700 mb-3 border-b pb-1">📝 Medical Background</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <textarea className="input" name="medicalHistory" placeholder="Medical History" value={formData.medicalHistory} onChange={handleChange} />
            <textarea className="input" name="medications" placeholder="Medications" value={formData.medications} onChange={handleChange} />
            <textarea className="input col-span-2" name="remarks" placeholder="Remarks" value={formData.remarks} onChange={handleChange} />
          </div>
        </div>

        {/* Clinical Indicators */}
        <div>
          <h3 className="text-xl font-semibold text-gray-700 mb-3 border-b pb-1">📊 Initial Clinical Indicators</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <input className="input" name="fvg" type="number" placeholder="Fasting Venous Glucose (FVG)" value={formData.fvg} onChange={handleChange} />
            <input className="input" name="hba1c1" type="number" step="0.1" placeholder="HbA1c After 1st Visit" value={formData.hba1c1} onChange={handleChange} />
            <input className="input" name="hba1c2" type="number" step="0.1" placeholder="HbA1c After 2nd Visit" value={formData.hba1c2} onChange={handleChange} />
            <input className="input" name="symptomBefore" type="number" placeholder="Symptom Severity (Before)" value={formData.symptomBefore} onChange={handleChange} />
            <input className="input" name="symptomAfter" type="number" placeholder="Symptom Severity (After)" value={formData.symptomAfter} onChange={handleChange} />
            <input className="input" name="hypoBefore" type="number" placeholder="Hypoglycemia Episodes/Week (Before)" value={formData.hypoBefore} onChange={handleChange} />
            <input className="input" name="hypoAfter" type="number" placeholder="Hypoglycemia Episodes/Week (After)" value={formData.hypoAfter} onChange={handleChange} />
          </div>
        </div>

        <div className="text-center">
          <button type="submit" className="mt-4 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded transition">
            Submit Patient Data
          </button>
        </div>
      </form>
    </div>
  );
};

// Tailwind component style shortcut
const style = document.createElement("style");
style.innerHTML = `
.input {
  @apply w-full border border-gray-300 px-4 py-2 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500;
}
`;
document.head.appendChild(style);

export default CreatePatient;
