import React, { useEffect, useState, useRef } from 'react';
import { useParams } from 'react-router-dom';
import Chart from 'chart.js/auto';
import './PatientProfile.css';

const PatientProfile = () => {
  const { id } = useParams();
  const [patient, setPatient] = useState(null);
  const chartRef = useRef(null);
  const chartInstanceRef = useRef(null);

  useEffect(() => {
    fetch(`http://localhost:8000/api/patients/${id}`)
      .then((res) => res.json())
      .then((data) => setPatient(data))
      .catch((err) => console.error('Error fetching patient:', err));
  }, [id]);

  useEffect(() => {
    if (patient && chartRef.current) {
      if (chartInstanceRef.current) chartInstanceRef.current.destroy();
      chartInstanceRef.current = new Chart(chartRef.current, {
        type: 'line',
        data: {
          labels: ['1st Visit', '2nd Visit'],
          datasets: [
            {
              label: 'HbA1c',
              data: [patient.hba1c_1st_visit, patient.hba1c_2nd_visit],
              borderColor: '#6366f1',
              backgroundColor: '#6366f1',
              tension: 0.3
            }
          ]
        },
        options: {
          plugins: { legend: { display: false } },
          scales: { x: { display: false }, y: { beginAtZero: false } }
        }
      });
    }
  }, [patient]);

  if (!patient) return <div className="p-6 text-center">Loading patient data...</div>;

  const hba1cDrop = patient.hba1c_1st_visit - patient.hba1c_2nd_visit;
  const symptomDrop = patient.symptom_severity_before - patient.symptom_severity_after;
  const hypoDrop = patient.hypo_before - patient.hypo_after;

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <div className="bg-white shadow-xl rounded-xl p-8">
        <h2 className="text-2xl font-bold mb-6 text-gray-800">Patient Profile</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Profile */}
          <div className="bg-gray-50 rounded-lg p-4 text-center">
            <img
              src={`https://ui-avatars.com/api/?name=${patient.name}&background=random`}
              alt="avatar"
              className="w-24 h-24 mx-auto rounded-full mb-3"
            />
            <h3 className="text-lg font-semibold">{patient.name}</h3>
            <p className="text-gray-500 text-sm">{patient.gender} | {patient.age} y/o</p>
            <span className="inline-block bg-green-100 text-green-800 text-xs px-3 py-1 mt-2 rounded-full">Stable</span>
          </div>

          {/* General Info */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-md font-semibold mb-3 text-gray-700">General Information</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li><strong>Medical History:</strong> {patient.medical_history}</li>
              <li><strong>Medications:</strong> {patient.medications}</li>
              <li><strong>Remarks:</strong> {patient.remarks}</li>
            </ul>
          </div>

          {/* Clinical Stats */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-md font-semibold mb-3 text-gray-700">Clinical Data</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li><strong>Insulin Type:</strong> {patient.insulin_regimen_type}</li>
              <li><strong>FVG:</strong> {patient.fvg}</li>
              <li><strong>HbA1c 1st Visit:</strong> {patient.hba1c_1st_visit}</li>
              <li><strong>HbA1c 2nd Visit:</strong> {patient.hba1c_2nd_visit}</li>
              <li><strong>Symptoms (Before):</strong> {patient.symptom_severity_before}</li>
              <li><strong>Symptoms (After):</strong> {patient.symptom_severity_after}</li>
              <li><strong>Hypo Episodes (Before):</strong> {patient.hypo_before}</li>
              <li><strong>Hypo Episodes (After):</strong> {patient.hypo_after}</li>
            </ul>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
          <div className="bg-green-50 border border-green-200 p-4 rounded text-green-700 text-sm text-center shadow-sm">
            <div className="text-xs uppercase font-bold text-green-600">HbA1c Drop</div>
            <div className="text-xl font-semibold">↓ {hba1cDrop}%</div>
          </div>
          <div className="bg-blue-50 border border-blue-200 p-4 rounded text-blue-700 text-sm text-center shadow-sm">
            <div className="text-xs uppercase font-bold text-blue-600">Symptom Relief</div>
            <div className="text-xl font-semibold">↓ {symptomDrop}</div>
          </div>
          <div className="bg-purple-50 border border-purple-200 p-4 rounded text-purple-700 text-sm text-center shadow-sm">
            <div className="text-xs uppercase font-bold text-purple-600">Hypo Episodes</div>
            <div className="text-xl font-semibold">↓ {hypoDrop}/wk</div>
          </div>
        </div>

        {/* Chart + Notes */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10">
          <div className="bg-gray-50 p-4 rounded shadow-sm">
            <h4 className="text-sm font-medium text-gray-700 mb-2">HbA1c Trend</h4>
            <canvas ref={chartRef} height={150}></canvas>
          </div>

          <div className="bg-gray-50 p-4 rounded shadow-sm">
            <h4 className="text-sm font-medium text-gray-700 mb-2">Recent Notes</h4>
            <ul className="text-xs text-gray-600 space-y-2">
              <li>🟢 Adjusted to {patient.insulin_regimen_type} insulin</li>
              <li>📉 HbA1c dropped to {patient.hba1c_2nd_visit}</li>
              <li>📅 Next checkup in 3 months</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientProfile;
