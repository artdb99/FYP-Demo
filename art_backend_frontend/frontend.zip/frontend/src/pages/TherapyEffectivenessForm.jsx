import React, { useEffect, useState, useRef } from 'react';
import { useParams } from 'react-router-dom';
import Chart from 'chart.js/auto';

const TherapyEffectivenessPage = () => {
  const { id } = useParams();
  const [patient, setPatient] = useState(null);
  const chartRef = useRef(null);
  const chartInstanceRef = useRef(null);

  useEffect(() => {
    fetch(`http://localhost:8000/api/patients/${id}`)
      .then((res) => res.json())
      .then((data) => setPatient(data))
      .catch((err) => console.error('Error fetching patient data:', err));
  }, [id]);

  useEffect(() => {
    if (patient && chartRef.current) {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }

      chartInstanceRef.current = new Chart(chartRef.current, {
        type: 'line',
        data: {
          labels: ['1st Visit', '2nd Visit'],
          datasets: [
            {
              label: 'HbA1c (%)',
              data: [patient.hba1c_1st_visit, patient.hba1c_2nd_visit],
              borderColor: '#4f46e5',
              backgroundColor: '#c7d2fe',
              tension: 0.3
            },
            {
              label: 'Symptom Severity',
              data: [patient.symptom_severity_before, patient.symptom_severity_after],
              borderColor: '#14b8a6',
              backgroundColor: '#ccfbf1',
              tension: 0.3
            },
            {
              label: 'Hypo Episodes/Week',
              data: [patient.hypo_before, patient.hypo_after],
              borderColor: '#f97316',
              backgroundColor: '#fde68a',
              tension: 0.3
            }
          ]
        },
        options: {
          responsive: true,
          scales: {
            y: {
              beginAtZero: true,
              title: { display: true, text: 'Value' }
            }
          }
        }
      });
    }
  }, [patient]);

  if (!patient) return <div className="p-6 text-center">Loading therapy effectiveness...</div>;

  const hba1cDrop = patient.hba1c_1st_visit - patient.hba1c_2nd_visit;
  const symptomDrop = patient.symptom_severity_before - patient.symptom_severity_after;
  const hypoDrop = patient.hypo_before - patient.hypo_after;

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <div className="bg-white shadow-xl rounded-xl p-8 space-y-8">
        {/* Patient Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">{patient.name}</h2>
            <p className="text-sm text-gray-500">{patient.age} y/o — {patient.gender}</p>
          </div>
          <span className="inline-block bg-green-100 text-green-800 px-3 py-1 text-sm rounded-full">
            Therapy Monitoring
          </span>
        </div>

        {/* Effectiveness Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-gray-50 rounded-lg p-4 text-center">
            <h3 className="font-semibold text-sm text-gray-700">HbA1c Reduction</h3>
            <p className={`text-lg font-bold ${hba1cDrop > 0 ? 'text-green-600' : 'text-red-500'}`}>
              {hba1cDrop > 0 ? `↓ ${hba1cDrop.toFixed(1)}%` : `↑ ${Math.abs(hba1cDrop).toFixed(1)}%`}
            </p>
          </div>
          <div className="bg-gray-50 rounded-lg p-4 text-center">
            <h3 className="font-semibold text-sm text-gray-700">Symptom Score</h3>
            <p className={`text-lg font-bold ${symptomDrop > 0 ? 'text-green-600' : 'text-red-500'}`}>
              {symptomDrop > 0 ? `↓ ${symptomDrop}` : `↑ ${Math.abs(symptomDrop)}`}
            </p>
          </div>
          <div className="bg-gray-50 rounded-lg p-4 text-center">
            <h3 className="font-semibold text-sm text-gray-700">Hypo Episodes</h3>
            <p className={`text-lg font-bold ${hypoDrop > 0 ? 'text-green-600' : 'text-red-500'}`}>
              {hypoDrop > 0 ? `↓ ${hypoDrop}` : `↑ ${Math.abs(hypoDrop)}`}
            </p>
          </div>
        </div>

        {/* Chart */}
        <div className="bg-gray-50 rounded-lg p-6">
          <h4 className="text-md font-semibold mb-4 text-gray-700">Progress Over Time</h4>
          <canvas ref={chartRef}></canvas>
        </div>

        {/* Recommendation */}
        <div className="bg-blue-50 border border-blue-200 text-blue-700 text-sm rounded p-4">
          <h4 className="font-semibold mb-2">💡 Recommendation</h4>
          <p>
            Based on current trends, therapy appears effective. Continue monitoring HbA1c quarterly. Consider tapering insulin if trend sustains.
          </p>
        </div>

        {/* Treatment Overview */}
        <div className="bg-white border border-gray-200 p-4 rounded-lg">
          <h4 className="text-sm font-semibold text-gray-800 mb-3">📝 Treatment Overview</h4>
          <ul className="text-sm text-gray-700 space-y-1">
            <li><strong>Insulin Type:</strong> {patient.insulin_regimen_type}</li>
            <li><strong>FVG:</strong> {patient.fvg}</li>
            <li><strong>Medications:</strong> {patient.medications}</li>
            <li><strong>Remarks:</strong> {patient.remarks}</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default TherapyEffectivenessPage;
