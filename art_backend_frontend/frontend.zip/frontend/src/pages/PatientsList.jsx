import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const PatientsList = () => {
  const [patients, setPatients] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8000/api/patients')
      .then((res) => res.json())
      .then((data) => setPatients(data))
      .catch((err) => console.error('Error:', err));
  }, []);

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-6 flex justify-between items-center">
        <h2 className="text-2xl font-semibold text-gray-800">Patient List</h2>
        <Link
          to="/patients/create"
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
        >
          + Add Patient
        </Link>
      </div>

      <div className="overflow-x-auto bg-white shadow rounded-lg">
        <table className="min-w-full text-sm text-left text-gray-700">
          <thead className="bg-gray-100 border-b text-xs uppercase font-medium text-gray-600">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Age</th>
              <th className="px-4 py-3">Gender</th>
              <th className="px-4 py-3">Insulin Regimen</th>
              <th className="px-4 py-3">FVG</th>
              <th className="px-4 py-3">HbA1c (1st)</th>
              <th className="px-4 py-3">HbA1c (2nd)</th>
              <th className="px-4 py-3">Symptoms (Before)</th>
              <th className="px-4 py-3">Symptoms (After)</th>
              <th className="px-4 py-3">Hypo/wk (Before)</th>
              <th className="px-4 py-3">Hypo/wk (After)</th>
              <th className="px-4 py-3">Remarks</th>
              <th className="px-4 py-3">Action</th>
            </tr>
          </thead>
          <tbody>
            {patients.map((p) => (
              <tr key={p.id} className="border-b hover:bg-gray-50">
                <td className="px-4 py-3 font-medium text-blue-600">
                  <Link to={`/patient/${p.id}`} className="hover:underline">{p.name}</Link>
                </td>
                <td className="px-4 py-3">{p.age}</td>
                <td className="px-4 py-3">{p.gender}</td>
                <td className="px-4 py-3">{p.insulin_regimen_type || '-'}</td>
                <td className="px-4 py-3">{p.fvg || '-'}</td>
                <td className="px-4 py-3">{p.hba1c_1st_visit || '-'}</td>
                <td className="px-4 py-3">{p.hba1c_2nd_visit|| '-'}</td>
                <td className="px-4 py-3">{p.symptom_severity_before || '-'}</td>
                <td className="px-4 py-3">{p.symptom_severity_after || '-'}</td>
                <td className="px-4 py-3">{p.hypo_before || '-'}</td>
                <td className="px-4 py-3">{p.hypo_after || '-'}</td>
                <td className="px-4 py-3">{p.remarks || '-'}</td>
                <td className="px-4 py-3">
                  <Link
                    to={`/patient/${p.id}`}
                    className="text-blue-500 hover:underline text-sm"
                  >
                    View
                  </Link>
                </td>
              </tr>
            ))}
            {patients.length === 0 && (
              <tr>
                <td colSpan="13" className="text-center py-6 text-gray-500">
                  No patient records found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PatientsList;
