function TreatmentRecommendation() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      <h1 className="text-3xl font-bold mb-2">Personalized Treatment Plans</h1>
      <p className="text-gray-600 mb-8">
        Based on your risk assessment and therapy effectiveness analysis, we create customized treatment plans tailored to your needs.
      </p>

      {/* Three Option Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <div className="bg-blue-50 p-6 rounded-lg shadow-sm">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-blue-500 text-2xl">💊</span>
            <h3 className="font-bold text-lg">Medication</h3>
          </div>
          <p className="text-gray-600 mb-2">
            Personalized pharmaceutical recommendations based on your profile and predicted effectiveness.
          </p>
          <a href="#" className="text-blue-600 font-medium hover:underline">View Options →</a>
        </div>

        <div className="bg-green-50 p-6 rounded-lg shadow-sm">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-green-500 text-2xl">🧠</span>
            <h3 className="font-bold text-lg">Therapy</h3>
          </div>
          <p className="text-gray-600 mb-2">
            Evidence-based therapeutic approaches matched to your condition and preferences.
          </p>
          <a href="#" className="text-green-600 font-medium hover:underline">View Options →</a>
        </div>

        <div className="bg-purple-50 p-6 rounded-lg shadow-sm">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-purple-500 text-2xl">💜</span>
            <h3 className="font-bold text-lg">Lifestyle</h3>
          </div>
          <p className="text-gray-600 mb-2">
            Diet, exercise, and wellness strategies to complement your treatment plan.
          </p>
          <a href="#" className="text-purple-600 font-medium hover:underline">View Options →</a>
        </div>
      </div>

      {/* Treatment Journey Steps */}
      <div className="bg-white rounded-lg shadow-md p-6 border">
        <h2 className="text-xl font-semibold mb-6">Your Treatment Journey</h2>
        <ul className="space-y-6">
          {[
            {
              step: 'Initial Assessment',
              description: 'Complete our comprehensive health evaluation to establish your baseline.',
            },
            {
              step: 'Personalized Plan',
              description: 'Receive your customized treatment plan with multiple options.',
            },
            {
              step: 'Implementation',
              description: 'Begin your treatment with guidance from our platform and professionals.',
            },
            {
              step: 'Monitoring',
              description: 'Track your progress with our tools and adjust treatment as needed.',
            },
            {
              step: 'Maintenance',
              description: 'Sustain your health gains with long-term strategies and support.',
            },
          ].map((item, index) => (
            <li key={index} className="flex items-start gap-4">
              <div className="flex flex-col items-center">
                <div className="bg-blue-100 text-blue-700 font-bold rounded-full w-8 h-8 flex items-center justify-center">{index + 1}</div>
                <div className="w-px bg-blue-200 flex-1 mt-1" />
              </div>
              <div>
                <h4 className="font-semibold">{item.step}</h4>
                <p className="text-gray-600">{item.description}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default TreatmentRecommendation;
