import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const TherapyDashboard = () => {
  const [patients, setPatients] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('http://localhost:8000/api/patients')
      .then(res => res.json())
      .then(data => {
        setPatients(data);
        setFiltered(data);
      });
  }, []);

  useEffect(() => {
    const q = search.toLowerCase();
    setFiltered(patients.filter(p => p.name.toLowerCase().includes(q)));
  }, [search, patients]);

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">Therapy Effectiveness Dashboard</h2>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-blue-100 text-blue-900 p-4 rounded shadow">
          <h4 className="text-sm font-semibold">Total Patients</h4>
          <p className="text-2xl font-bold">{patients.length}</p>
        </div>
        <div className="bg-green-100 text-green-900 p-4 rounded shadow">
          <h4 className="text-sm font-semibold">Improved Patients</h4>
          <p className="text-2xl font-bold">0</p>
        </div>
        <div className="bg-red-100 text-red-900 p-4 rounded shadow">
          <h4 className="text-sm font-semibold">Needs Review</h4>
          <p className="text-2xl font-bold">0</p>
        </div>
      </div>

      {/* Search */}
      <input
        type="text"
        placeholder="Search patient..."
        className="w-full md:w-1/2 p-2 mb-6 border rounded"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {/* Patient List */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map(p => (
            <Link
            to={`/therapy-effectiveness/${p.id}`}
            key={p.id}
            className="block p-4 border rounded-lg shadow hover:shadow-md transition cursor-pointer"
            >
            <h4 className="font-semibold text-lg text-blue-700">{p.name}</h4>
            <p className="text-sm text-gray-600">{p.age} y/o — {p.gender}</p>
            <p className="text-xs text-gray-500 mt-1">Updated: {new Date(p.updated_at).toLocaleDateString()}</p>
            </Link>
        ))}
        </div>

      {/* Recent Activity */}
      <div className="mt-10">
        <h3 className="text-lg font-semibold mb-3">Recent Activity</h3>
        <ul className="text-sm space-y-2 text-gray-700">
          {patients.slice(-3).reverse().map(p => (
            <li key={p.id}>
              <span className="font-semibold">{p.name}</span> was updated on <span className="text-gray-500">{new Date(p.updated_at).toLocaleDateString()}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default TherapyDashboard;
