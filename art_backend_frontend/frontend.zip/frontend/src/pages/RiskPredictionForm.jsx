import { useState } from 'react';
import axios from 'axios';

function RiskPredictionForm() {
  const [formData, setFormData] = useState({
    HbA1c1: '',
    HbA1c2: '',
    FVG1: '',
    FVG2: '',
    Avg_FVG_1_2: '',
    ReductionA: '',
    ReductionA_per_day: '',
    FVG_Delta_1_2: ''
  });

  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setResult(null);
    setError(null);

    try {
      const response = await axios.post('http://127.0.0.1:8000/api/predict', formData);
      setResult(response.data.prediction);
    } catch (err) {
      setError('Prediction failed. Please check the input or server.');
    }
  };

  return (
    <div className="px-4 py-8 max-w-6xl mx-auto">
      <h2 className="text-3xl font-bold mb-2 text-gray-800">Health Risk Prediction</h2>
      <p className="text-gray-600 mb-8">
        Our advanced AI analyzes your health data to predict potential risks and provide personalized recommendations.
      </p>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-5">
          <InputField label="HbA1c1" name="HbA1c1" value={formData.HbA1c1} handleChange={handleChange} />
          <InputField label="HbA1c2" name="HbA1c2" value={formData.HbA1c2} handleChange={handleChange} />
          <InputField label="FVG1" name="FVG1" value={formData.FVG1} handleChange={handleChange} />
          <InputField label="FVG2" name="FVG2" value={formData.FVG2} handleChange={handleChange} />
          <InputField label="Avg_FVG_1_2" name="Avg_FVG_1_2" value={formData.Avg_FVG_1_2} handleChange={handleChange} />
          <InputField label="Reduction A" name="ReductionA" value={formData.ReductionA} handleChange={handleChange} />
          <InputField label="ReductionA_per_day" name="ReductionA_per_day" value={formData.ReductionA_per_day} handleChange={handleChange} />
          <InputField label="FVG_Delta_1_2" name="FVG_Delta_1_2" value={formData.FVG_Delta_1_2} handleChange={handleChange} />
        </div>

        <div className="bg-gray-100 p-6 rounded-lg shadow-md flex items-center justify-center text-center">
          {result ? (
            <div>
              <p className="text-xl text-green-600 font-semibold">Predicted Risk: {result}</p>
            </div>
          ) : (
            <div className="text-gray-500">
              <svg className="w-10 h-10 mx-auto mb-2" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 17l6-6 4 4 8-8" />
              </svg>
              <p>Complete the form to see your personalized risk assessment</p>
            </div>
          )}
        </div>
      </form>

      <div className="mt-6">
        <button
          type="submit"
          onClick={handleSubmit}
          className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-medium py-2 px-6 rounded shadow hover:from-blue-600 hover:to-indigo-700 transition"
        >
          Calculate Risk
        </button>

        {error && (
          <div className="mt-4 text-red-600">
            {error}
          </div>
        )}
      </div>
    </div>
  );
}

function InputField({ label, name, value, handleChange }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <input
        type="number"
        name={name}
        value={value}
        onChange={handleChange}
        required
        className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
      />
    </div>
  );
}

export default RiskPredictionForm;
